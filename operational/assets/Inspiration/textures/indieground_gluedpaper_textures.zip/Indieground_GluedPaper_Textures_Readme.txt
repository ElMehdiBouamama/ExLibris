GLUED PAPER TEXTURES
by Indieground


DETAILS
---------
- 5 .JPEG Files
- 3000x4500 px
- 300 dpi
- Real Glued Paper


-------------------------------------------------------

THANKS FOR DOWNLOADING THIS FREE RESOURCE,

BE SURE TO MAKE A USE OF IT THAT AGREES WITH THE TERMS & CONDITIONS http://www.indieground.net/terms-conditions/

FOR ANY ADDITIONAL SUPPORT OR QUESTION JUST CONTACT US!


Indieground